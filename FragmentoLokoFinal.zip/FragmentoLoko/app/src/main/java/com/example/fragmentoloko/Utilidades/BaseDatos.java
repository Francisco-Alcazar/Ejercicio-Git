package com.example.fragmentoloko.Utilidades;


    public class BaseDatos {
        //CREAMOS LOS ATRIBUTOS PARA LA TABLA CONTACTO

    public static final String BASE_DATOS_CONTACTOS = "ContactosBBDD";
    public static final String TABLA_CONTACTOS = "contactos";
    public static final String CAMPO_ID_CONTACTO = "id";
    public static final String CAMPO_NOMBRE = "nombre";
    public static final String CAMPO_TELÉFONO = "telefono";
    public static final String CAMPO_E_MAIL = "email";
    public static final String CAMPO_DIRECCION = "direccion";


    //INCIAMOS LA CREACIÓN  DE TABLAS CANCIONES
    public static final String CREAR_TABLA_CONTACTOS = " CREATE TABLE " +
            TABLA_CONTACTOS + " ( " +
            CAMPO_ID_CONTACTO+ " INTEGER, " +
            CAMPO_NOMBRE + " TEXT, " +
            CAMPO_TELÉFONO + " INTEGER, " +
            CAMPO_E_MAIL + " TEXT, " +
            CAMPO_DIRECCION + " TEXT, " +
            "PRIMARY KEY( " + CAMPO_ID_CONTACTO + " AUTOINCREMENT));";



    //CREAMOS LOS ATRIBUTOS PARA LA TABLA USUARIOS_REGISTRADOS
    public static final String TABLA_USUARIOS_REGISTRADO = "usuariosRegistrado";
    public static final String  CAMPO_NOMBRE_USUARIO= "nombreUsuario";
    public static final String CAMPO_CONTRASÑA = "contraseñaUsuario";
    public static final String CAMPO_ID_USUARIO = "idusuario";

    public static final String CREAR_TABLA_USUARIOS_REGISTRADOS = " CREATE TABLE " +
            TABLA_USUARIOS_REGISTRADO + " ( " +
            CAMPO_ID_CONTACTO + " INTEGER, " +
            CAMPO_NOMBRE_USUARIO + " TEXT, " +
            CAMPO_CONTRASÑA + " TEXT, " +
            "PRIMARY KEY( " + CAMPO_ID_CONTACTO + " AUTOINCREMENT));";


        public static final String TABLA_CONTACTOS_OCULTOS = "contactosOcultos";

    public static final String CREA_TABLA_CONTACTOS_OCULTOS = " CREATE TABLE " +
            TABLA_CONTACTOS_OCULTOS + " ( " +
            CAMPO_ID_CONTACTO + " INTEGER, " +
            CAMPO_NOMBRE + " TEXT, " +
            CAMPO_TELÉFONO + " INTEGER, " +
            CAMPO_E_MAIL + " TEXT, " +
            CAMPO_DIRECCION + " TEXT, " +
            "PRIMARY KEY( " + CAMPO_ID_CONTACTO + " AUTOINCREMENT));";


    }
