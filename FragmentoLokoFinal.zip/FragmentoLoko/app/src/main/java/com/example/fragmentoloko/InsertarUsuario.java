package com.example.fragmentoloko;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.example.fragmentoloko.Entidades.Usuarios;
import com.example.fragmentoloko.Utilidades.BaseDatos;
import com.example.fragmentoloko.Utilidades.ConexionSQLiteBaseDatos;
import com.google.android.material.snackbar.Snackbar;

import javax.xml.transform.Result;

public class InsertarUsuario extends AppCompatActivity {
    EditText campoUsuario, campoContrasenia, campoContraseniaRepe;
    Button btnInsertarUsuario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insertar_usuario);


        campoUsuario = (EditText) findViewById(R.id.editTextTextUsuario);
        campoContrasenia = (EditText) findViewById(R.id.editTextTextPassword3);
        campoContraseniaRepe = (EditText) findViewById(R.id.editTextTextPassword3Rep);
        btnInsertarUsuario = (Button) findViewById(R.id.buttonInsertarUsuarioNuevo);


        btnInsertarUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!campoUsuario.getText().toString().isEmpty() && !campoContrasenia.getText().toString().isEmpty() && !campoContraseniaRepe.getText().toString().isEmpty()){
                     if(campoContrasenia.getText().toString().toUpperCase().equals(campoContraseniaRepe.getText()
                        .toString().toUpperCase())){
                        for(int i = 0; i < campoContrasenia.getText().toString().length(); i++){
                            if(Character.isDigit(campoContrasenia.getText().toString().charAt(i))){
                                insertarNuevoUsuario();
                                Snackbar mensaje = Snackbar.make(view, "Se ha añadido correctamente", 2000);
                                mensaje.show();
                            }

                        }
                     }else{

                         Snackbar mensaje = Snackbar.make(view, "Las contraseñas no coinciden o no tienen un carácter numérico", 2000);
                         mensaje.show();
                    }

                }else{

                    Snackbar mensaje = Snackbar.make(view, "Algún campo no está relleno", 2000);
                    mensaje.show();

                }

            }
        });

    }

    private void insertarNuevoUsuario() {


        ConexionSQLiteBaseDatos conn = new ConexionSQLiteBaseDatos(this, BaseDatos.BASE_DATOS_CONTACTOS, null, 1);



        SQLiteDatabase db= conn.getWritableDatabase();
        String insert = "INSERT INTO " + BaseDatos.TABLA_USUARIOS_REGISTRADO+ " ( "
                + BaseDatos.CAMPO_NOMBRE_USUARIO +" , "
                + BaseDatos.CAMPO_CONTRASÑA + " ) "
                + " VALUES('"
                + campoUsuario.getText().toString() + "' , '"
                + campoContrasenia.getText() + "' );";

        db.execSQL(insert);
        db.close();
    }
}