package com.example.fragmentoloko;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import com.example.fragmentoloko.ConatctosOcultos.InsertarContactoOculto;


public class MainActivity extends AppCompatActivity {
    FragmentTransaction transicion; //Objeto para hecr la transicion
    Fragment fragmentoContactos, fragmentoInicio;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fragmentoContactos = new fragment_item();

        transicion = getSupportFragmentManager().beginTransaction();
        transicion.replace(R.id.nuevoFragment, fragmentoContactos);
        transicion.commit();

        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);

        ActionBar ab = getSupportActionBar();

        // Enable the Up button
        ab.setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }


    public void onCLick(View view) {

        Intent inten = null;


        if (inten != null) {

            startActivity(inten);

        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu items for use in the action bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        Intent intent = null;
        switch (item.getItemId()) {
            case R.id.aniaOculto:
                intent = new Intent(MainActivity.this, InsertarContactoOculto.class);

                break;


            case R.id.iniSes:
                intent = new Intent(MainActivity.this, InsertarContacto2.class);

                break;

            case R.id.aniadirContacto:
                intent = new Intent(MainActivity.this, InsertarContacto2.class);
                break;
            default:
                return super.onOptionsItemSelected(item);

        }


        if(intent != null){
            startActivity(intent);
        }
        return false;

    }

    public void onClick2(View view){
        switch (view.getId()){
            case R.id.imageButtonCuenta:
                Intent intent = new Intent(MainActivity.this, IniciarSesionActividad.class);
                startActivity(intent);
                break;
        }
    }
    public void onClick(View view){
        transicion = getSupportFragmentManager().beginTransaction();

        switch (view.getId()){
            case R.id.imageButtonAgenda:
                transicion.replace(R.id.nuevoFragment, fragmentoContactos);
                //Volver atras
                transicion.addToBackStack(null);
                break;
        }
        transicion.commit();

    }
}