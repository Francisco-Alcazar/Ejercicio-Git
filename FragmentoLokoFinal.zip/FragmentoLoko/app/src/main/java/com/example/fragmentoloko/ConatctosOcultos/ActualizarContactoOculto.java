package com.example.fragmentoloko.ConatctosOcultos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.fragmentoloko.Entidades.Contacto;
import com.example.fragmentoloko.MostrarDatosContactosOcultos;
import com.example.fragmentoloko.R;
import com.example.fragmentoloko.Utilidades.BaseDatos;
import com.example.fragmentoloko.Utilidades.ConexionSQLiteBaseDatos;

import java.util.ArrayList;

public class ActualizarContactoOculto extends AppCompatActivity {

    EditText nombre, telefono, e_mail,direccion;
    Button nuevo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actualizar_contacto_oculto);
        nombre = (EditText) findViewById(R.id.textViewNombreContactoActualizar1);
        telefono = (EditText) findViewById(R.id.textView2TelefonoContactoActualizar1);
        e_mail = (EditText) findViewById(R.id.textView3ContactosEMailActualizar1);
        direccion = (EditText)  findViewById(R.id.textView4DireccionContactosActualizar1);
        nuevo = (Button) findViewById(R.id.btnActualizarContacto);
        nuevaClase();
        nuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                actualizarContacto();
                Intent intent = new Intent(ActualizarContactoOculto.this, MostrarDatosContactosOcultos.class);
                startActivity(intent);
            }
        });


    }

    private void nuevaClase(){

        ConexionSQLiteBaseDatos conn = new ConexionSQLiteBaseDatos(this, BaseDatos.BASE_DATOS_CONTACTOS, null, 1);



        ListView nuevaLista = (ListView) this.findViewById(R.id.listViewContactosOcultos);


        ArrayList<String> listaInformacion = new ArrayList<String>();
        ArrayList<Contacto> arrayListContactos = new ArrayList<Contacto>();

        SQLiteDatabase db = conn.getReadableDatabase(); //Que sea legible, ya que quiero hacer una consulta de lectura
        String selectAll = "SELECT * FROM " + BaseDatos.TABLA_CONTACTOS_OCULTOS;

        //Cositas para la conexion
        Contacto contac = null;


        Cursor cursor = db.rawQuery(selectAll, null);

        while(cursor.moveToNext()){
            contac = new Contacto();

            contac.setId(cursor.getInt(0));
            contac.setNombre(cursor.getString(1));
            contac.setTelefono(cursor.getInt(2));
            contac.setE_mail(cursor.getString(3));
            contac.setDireccion(cursor.getString(4));

            arrayListContactos.add(contac);
        }

        for(int i = 0; i < arrayListContactos.size(); i++){
            listaInformacion.add("* Nombre: " +
                    arrayListContactos.get(i).getNombre() + "\n* Telefono " +
                    arrayListContactos.get(i).getTelefono()
            );


        }

        Bundle ssaquito2 = getIntent().getExtras();
        int codigo = ssaquito2.getInt("keynuevo");


        nombre.setText(arrayListContactos.get(codigo).getNombre());
        telefono.setText(arrayListContactos.get(codigo).getTelefono().toString());
        e_mail.setText(arrayListContactos.get(codigo).getE_mail().toString());
        direccion.setText(arrayListContactos.get(codigo).getDireccion().toString());



    }

    private void actualizarContacto() {

        ConexionSQLiteBaseDatos conn = new ConexionSQLiteBaseDatos(this, BaseDatos.BASE_DATOS_CONTACTOS, null, 1);
        SQLiteDatabase db = conn.getReadableDatabase(); //Que sea legible, ya que quiero hacer una consulta de lectura
        String selectAll = "SELECT * FROM " + BaseDatos.TABLA_CONTACTOS_OCULTOS;
        Contacto contac = null;
        Cursor cursor = db.rawQuery(selectAll, null);
        ArrayList<Contacto> arrayListContactos = new ArrayList<Contacto>();

        while(cursor.moveToNext()){
            contac = new Contacto();

            contac.setId(cursor.getInt(0));
            contac.setNombre(cursor.getString(1));
            contac.setTelefono(cursor.getInt(2));
            contac.setE_mail(cursor.getString(3));
            contac.setDireccion(cursor.getString(4));

            arrayListContactos.add(contac);
        }
        Bundle ssaquito = getIntent().getExtras();
        int codigo = ssaquito.getInt("key");

        String update = "UPDATE " +BaseDatos.TABLA_CONTACTOS_OCULTOS + " SET "
                + BaseDatos.CAMPO_NOMBRE + " = '"
                + nombre.getText().toString() + "', "
                + BaseDatos.CAMPO_TELÉFONO + " = '"
                + telefono.getText().toString() + "' , "
                + BaseDatos.CAMPO_E_MAIL + " = '"
                + e_mail.getText().toString() + "' ,"
                +BaseDatos.CAMPO_DIRECCION + "= '"
                + direccion.getText().toString() + "' WHERE "
                + BaseDatos.CAMPO_NOMBRE + "= '"
                + arrayListContactos.get(codigo).getNombre() + "';";

        db.execSQL(update);
        db.close();
    }


}