package com.example.fragmentoloko.Utilidades;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ConexionSQLiteBaseDatos extends SQLiteOpenHelper {

    //Manejo base datos                 version de base de datos
    public ConexionSQLiteBaseDatos(Context ctx, String nombreBaseDatos, SQLiteDatabase.CursorFactory factory,
                          int verdion ){
        super(ctx, nombreBaseDatos, factory, verdion);

    }



    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(BaseDatos.CREA_TABLA_CONTACTOS_OCULTOS);
        sqLiteDatabase.execSQL(BaseDatos.CREAR_TABLA_CONTACTOS);
        sqLiteDatabase.execSQL(BaseDatos.CREAR_TABLA_USUARIOS_REGISTRADOS);


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+ BaseDatos.TABLA_CONTACTOS_OCULTOS);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+ BaseDatos.TABLA_CONTACTOS);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + BaseDatos.TABLA_USUARIOS_REGISTRADO);
        onCreate(sqLiteDatabase);


    }
}




