package com.example.fragmentoloko;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.arch.core.internal.SafeIterableMap;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.fragmentoloko.Entidades.Contacto;
import com.example.fragmentoloko.Utilidades.ActualizarContactoSenialado;
import com.example.fragmentoloko.Utilidades.BaseDatos;
import com.example.fragmentoloko.Utilidades.ConexionSQLiteBaseDatos;

import org.w3c.dom.Text;

import java.util.ArrayList;


public class fragment_item extends Fragment {


    public fragment_item() {
        // Required empty public constructor
    }


    public static fragment_item newInstance(String param1, String param2) {
        fragment_item fragment = new fragment_item();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_item, container, false);
        return view;
    }
    private void consultarListaCanciones() {
    }


    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstance) {
        super.onViewCreated(view, savedInstance);



        //Hacemos la conexión con la base de datos

        ConexionSQLiteBaseDatos conn = new ConexionSQLiteBaseDatos(getActivity(), BaseDatos.BASE_DATOS_CONTACTOS, null, 1);

        //Sincronizando la listView
        ListView nuevaLista = (ListView) getActivity().findViewById(R.id.nuevaLista);

        //Creamos los arrays para guardar información en ellos
        ArrayList<String> listaInformacion = new ArrayList<String>();
        ArrayList<Contacto> arrayListContactos = new ArrayList<Contacto>();

        //Creamos un objetoSQLiteDatabase con el que "encendemos" la comnexión y hacemos la consulta
        SQLiteDatabase db = conn.getReadableDatabase(); //Que sea legible, ya que quiero hacer una consulta de lectura
        String selectAll = "SELECT * FROM " + BaseDatos.TABLA_CONTACTOS;

        //Creamos el contacto para guardarlo en el array de Contactos
        Contacto contac = null;

        //Este cursor nos permitirá ejecutar la queary que hemos declarado enteriormente y recorrerlo con un while
        Cursor cursor = db.rawQuery(selectAll, null);

        while(cursor.moveToNext()){
            contac = new Contacto();

            contac.setId(cursor.getInt(0));
            contac.setNombre(cursor.getString(1));
            contac.setTelefono(cursor.getInt(2));
            contac.setE_mail(cursor.getString(3));
            contac.setDireccion(cursor.getString(4));
            //Guardamos el contacto
            arrayListContactos.add(contac);
        }
        //Guardamos la información recogida en el paso anterior en el lista información
        for(int i = 0; i < arrayListContactos.size(); i++){
            listaInformacion.add("* Nombre: " +
                    arrayListContactos.get(i).getNombre() + "\n* Telefono " +
                    arrayListContactos.get(i).getTelefono()
            );


        }
            //Creamos un ArrayAdapter con el que cogemos la información de lista información y la adaptamos para poder
        //mostrarla en la lista
            ArrayAdapter<String> adaptador = new ArrayAdapter(getActivity().getApplicationContext(), android.R.layout.simple_list_item_1, listaInformacion);
            nuevaLista.setAdapter(adaptador);
            //adaptador.notifyDataSetChanged();
            //adaptador.notifyDataSetInvalidated();


            //Cuando hacemos click sobre un elemento de la lista podemos ver la información para editarla
            nuevaLista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    Intent inten = new Intent(getActivity(), ActualizarContactoSenialado.class);
                    int id = arrayListContactos.get(i).getId();
                    Bundle saquito = new Bundle();
                    saquito.putInt("key", i);

                    getParentFragmentManager().setFragmentResult("requestKey", saquito);
                    inten.putExtras(saquito);

                    startActivity(inten);
                }
            });
            //Cuando dejamos presionado un elemento de la lista, esta se borrará por completo
            //añadiendo una notificáción de que el contacto ha sido borrado perfectamente
            nuevaLista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                    int id = arrayListContactos.get(i).getId();


                    AlertDialog.Builder borrarSiNo = new AlertDialog.Builder(getActivity());
                    borrarSiNo.setMessage("¿Desea eliminar el contacto señalado?")
                            .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {

                                    String borrarContacto = "DELETE FROM " + BaseDatos.TABLA_CONTACTOS
                                            + " WHERE " + BaseDatos.CAMPO_ID_CONTACTO + " = " + id;

                                    try {
                                        SQLiteDatabase db = conn.getWritableDatabase();
                                        db.execSQL(borrarContacto);
                                        db.close();

                                        getActivity().recreate();
                                    }catch (Exception e){
                                        Toast.makeText(getActivity(),
                                                "La eliminación ha fallado." +
                                                        e.getMessage().toString(),
                                                Toast.LENGTH_SHORT).show();
                                    }
                                }


                            }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Toast.makeText(getActivity(), "No se ha producido el borrado.", Toast.LENGTH_SHORT).show();
                        }
                    }).show();


                    return false;
                }
            });

          }





    }


