package com.example.fragmentoloko;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import com.example.fragmentoloko.Utilidades.ConexionSQLiteBaseDatos;
import com.example.fragmentoloko.Utilidades.BaseDatos;
import com.google.android.material.snackbar.Snackbar;

import javax.xml.transform.Result;

public class InsertarContacto2 extends AppCompatActivity {

    EditText campoNombre, campoTelefono, campoE_mail,campoDireccion;
    ImageButton btnInsertar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insertar_contacto2);

        campoNombre = (EditText) findViewById(R.id.editTextNombre);
        campoTelefono = (EditText) findViewById(R.id.editTextTelefono);
        campoE_mail = (EditText) findViewById(R.id.editTexte_mail);
        campoDireccion = (EditText) findViewById(R.id.editTextDireccion);
        btnInsertar = (ImageButton) findViewById(R.id.btnInsertarContactoOculto);

        btnInsertar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = null;

                //intent = new Intent(InsertarContacto.this, MainActivity.class);
                // startActivity(intent);
                //Decimos si el nombre y el teléfono están rellenos, si se pueda crear el contacto
                if(!campoNombre.getText().toString().isEmpty() && !campoTelefono.getText().toString().isEmpty()){
                    //Decimos que el teléfono debe ocupar 9 dígitos
                    if(campoTelefono.length() == 9) {


                        if(campoE_mail.getText().toString().indexOf("@") != -1){

                            insertarContacto();
                            Snackbar mensaje = Snackbar.make(view, "Se ha añadido correctamente", 2000);
                            mensaje.show();
                            Intent intent2 = new Intent(InsertarContacto2.this, MainActivity.class);
                            startActivity(intent2);
                        }else{
                            Snackbar mensaje = Snackbar.make(view, "No se ha podido añadir el contacto, comprueba que el \n" +
                                    "campo correo tenga el carácter @", 2000);
                            mensaje.show();
                        }
                    }else{
                        Snackbar mensaje = Snackbar.make(view, "No se ha podido añadir el contacto,\nRecuerda que" +
                                " el teléfono debe ocupar 9 números", 4000);
                        mensaje.show();

                    }

                }else {
                    Snackbar mensaje = Snackbar.make(view, "No se ha podido añadir el contacto,\n el nombre" +
                            "o el teléfono no están rellenos", 4000);
                    mensaje.show();
                }


                Result res;
            }
        });

    }

    private void insertarContacto() {

        ConexionSQLiteBaseDatos conn = new ConexionSQLiteBaseDatos(this, BaseDatos.BASE_DATOS_CONTACTOS, null, 1);

        SQLiteDatabase db= conn.getWritableDatabase();
        String insert = "INSERT INTO " + BaseDatos.TABLA_CONTACTOS + " ( "
                + BaseDatos.CAMPO_NOMBRE + " , "
                + BaseDatos.CAMPO_TELÉFONO + " , "
                + BaseDatos.CAMPO_E_MAIL + " , "
                + BaseDatos.CAMPO_DIRECCION + " ) "
                + " VALUES ('"
                + campoNombre.getText().toString() + "' , '"
                + campoTelefono.getText() + "' ,  '"
                + campoE_mail.getText().toString()
                + "' , '" + campoDireccion.getText().toString()
                + "') ; ";


        db.execSQL(insert);
        db.close();


    }
}