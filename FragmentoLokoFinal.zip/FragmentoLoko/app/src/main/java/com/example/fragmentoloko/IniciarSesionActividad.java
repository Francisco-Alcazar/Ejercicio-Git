package com.example.fragmentoloko;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.fragmentoloko.Entidades.Usuarios;
import com.example.fragmentoloko.Utilidades.BaseDatos;
import com.example.fragmentoloko.Utilidades.ConexionSQLiteBaseDatos;

import java.util.ArrayList;

public class IniciarSesionActividad extends AppCompatActivity {

    EditText cuenta, contrasenia;
    Button ini, regis;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iniciar_sesion_actividad);

        cuenta = (EditText) findViewById(R.id.planeUsuario);
        contrasenia = (EditText) findViewById(R.id.planeContrasenia);
        ini = (Button) findViewById(R.id.btnIniSesion);
        regis = (Button) findViewById(R.id.btnResgistrar);

        ini.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


               whileNuevo();
            }
        });

        regis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(IniciarSesionActividad.this, InsertarUsuario.class);
                startActivity(intent);
            }
        });

    }

    public ArrayList<Usuarios> consulta() {
        ConexionSQLiteBaseDatos conn = new ConexionSQLiteBaseDatos(this, BaseDatos.BASE_DATOS_CONTACTOS, null, 1);
        String selectAll = "SELECT * FROM " + BaseDatos.TABLA_USUARIOS_REGISTRADO;

        //Cositas para la conexion
        Usuarios usu = null;

        SQLiteDatabase db = conn.getReadableDatabase(); //Que sea legible, ya que quiero hacer una consulta de lectura

        Cursor cursor = db.rawQuery(selectAll, null);
        ArrayList<Usuarios> arrayListContactos = new ArrayList<Usuarios>();
        while (cursor.moveToNext()) {
            usu = new Usuarios();

            usu.setId(cursor.getInt(0));
            usu.setNombreUsu(cursor.getString(1));
            usu.setContrasenia(cursor.getString(2));


            arrayListContactos.add(usu);
        }


        return arrayListContactos;
    }

    public void iniciar(){

        Intent intent = new Intent(IniciarSesionActividad.this, MostrarDatosContactosOcultos.class);
        startActivity(intent);


    }

    public void whileNuevo(){
        ConexionSQLiteBaseDatos conn = new ConexionSQLiteBaseDatos(this, BaseDatos.BASE_DATOS_CONTACTOS, null, 1);

        ArrayList<Usuarios>  usuarioLista= consulta();
        //Cositas para la conexion
        Usuarios usu = null;

        SQLiteDatabase db = conn.getReadableDatabase(); //Que sea legible, ya que quiero hacer una consulta de lectura
        int i = 0;
        while(i < usuarioLista.size()) {

            if (cuenta.getText().toString().equals(usuarioLista.get(i).getNombreUsu().toString())) {
                iniciar();
            }
            i++;
        }

    }

}