package com.example.fragmentoloko;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.fragmentoloko.ConatctosOcultos.ActualizarContactoOculto;
import com.example.fragmentoloko.Entidades.Contacto;
import com.example.fragmentoloko.Entidades.Usuarios;
import com.example.fragmentoloko.Utilidades.ActualizarContactoSenialado;
import com.example.fragmentoloko.Utilidades.BaseDatos;
import com.example.fragmentoloko.Utilidades.ConexionSQLiteBaseDatos;

import java.util.ArrayList;

public class MostrarDatosContactosOcultos extends AppCompatActivity {

    ListView nuevaLista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_datos_contactos_ocultos);
        nuevaLista = (ListView) findViewById(R.id.listViewContactosOcultos);




        ConexionSQLiteBaseDatos conn = new ConexionSQLiteBaseDatos(this, BaseDatos.BASE_DATOS_CONTACTOS, null, 1);

        //Sincronizando la listView
        ListView nuevaLista = (ListView) findViewById(R.id.listViewContactosOcultos);

        //Creamos los arrays para guardar información en ellos
        ArrayList<String> listaInformacion = new ArrayList<String>();
        ArrayList<Contacto> arrayListUsuarios = new ArrayList<Contacto>();

        //Creamos un objetoSQLiteDatabase con el que "encendemos" la comnexión y hacemos la consulta
        SQLiteDatabase db = conn.getReadableDatabase(); //Que sea legible, ya que quiero hacer una consulta de lectura
        String selectAll = "SELECT * FROM " + BaseDatos.TABLA_CONTACTOS_OCULTOS;

        //Creamos el contacto para guardarlo en el array de Contactos
        Contacto contacto = null;

        //Este cursor nos permitirá ejecutar la queary que hemos declarado enteriormente y recorrerlo con un while
        Cursor cursor = db.rawQuery(selectAll, null);

        while(cursor.moveToNext()){
            contacto = new Contacto();

            contacto.setId(cursor.getInt(0));

            contacto.setNombre(cursor.getString(1));
            contacto.setTelefono(cursor.getInt(2));
            contacto.setE_mail(cursor.getString(3));
            contacto.setDireccion(cursor.getString(4));
            //Guardamos el contacto
            arrayListUsuarios.add(contacto);
        }
        //Guardamos la información recogida en el paso anterior en el lista información
        for(int i = 0; i < arrayListUsuarios.size(); i++){
            listaInformacion.add("* Nombre: " +
                    arrayListUsuarios.get(i).getNombre() + "\n* Telefono " +
                    arrayListUsuarios.get(i).getTelefono()
            );


        }
        //Creamos un ArrayAdapter con el que cogemos la información de lista información y la adaptamos para poder
        //mostrarla en la lista
        ArrayAdapter<String> adaptador = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listaInformacion);
        nuevaLista.setAdapter(adaptador);
        //adaptador.notifyDataSetChanged();
       // adaptador.notifyDataSetInvalidated();
        nuevaLista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Intent inten = new Intent(MostrarDatosContactosOcultos.this, ActualizarContactoOculto.class);
                int id = arrayListUsuarios.get(i).getId();
                Bundle saquito2 = new Bundle();
                saquito2.putInt("keynuevo", i);

                //getParentFragmentManager().setFragmentResult("requestKey", saquito);
                getSupportFragmentManager().setFragmentResult("requestKey", saquito2);
                inten.putExtras(saquito2);

                startActivity(inten);

             }
        });
        nuevaLista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                int idContactoOculto = arrayListUsuarios.get(i).getId();
                AlertDialog.Builder borrarSiNo = new AlertDialog.Builder(MostrarDatosContactosOcultos.this);
                borrarSiNo.setMessage("¿Desea eliminar el contacto señalado?")
                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {


                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {


                                String borrarContacto = "DELETE FROM " + BaseDatos.TABLA_CONTACTOS_OCULTOS
                                        + " WHERE " + BaseDatos.CAMPO_ID_CONTACTO + " = " + idContactoOculto;
                                try {
                                    SQLiteDatabase db = conn.getWritableDatabase();
                                    db.execSQL(borrarContacto);
                                    db.close();
                                   recreate();
                                    //getActivity().recreate();

                                }catch (Exception e){
                                    Toast.makeText(MostrarDatosContactosOcultos.this,
                                            "La eliminación ha fallado." +
                                                    e.getMessage().toString(),
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(MostrarDatosContactosOcultos.this, "No se ha producido el borrado.", Toast.LENGTH_SHORT).show();
                    }
                }).show();




                return false;
            }
        });


    }


    public void lista(){
    }
}