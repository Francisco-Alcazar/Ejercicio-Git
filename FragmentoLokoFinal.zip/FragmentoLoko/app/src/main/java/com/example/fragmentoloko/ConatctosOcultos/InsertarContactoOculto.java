package com.example.fragmentoloko.ConatctosOcultos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import com.example.fragmentoloko.MainActivity;
import com.example.fragmentoloko.R;
import com.example.fragmentoloko.Utilidades.BaseDatos;
import com.example.fragmentoloko.Utilidades.ConexionSQLiteBaseDatos;
import com.google.android.material.snackbar.Snackbar;

import javax.xml.transform.Result;

public class InsertarContactoOculto extends AppCompatActivity {

    EditText nombre, telefono, e_mail, direccion;
    ImageButton actualizar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insertar_contacto_oculto);

        nombre = (EditText) findViewById(R.id.editTextNombre);
        telefono = (EditText) findViewById(R.id.editTextTelefono);
        e_mail = (EditText) findViewById(R.id.editTexte_mail);
        direccion = (EditText) findViewById(R.id.editTextDireccion);
        actualizar = (ImageButton) findViewById(R.id.btnInsertarContactoOculto);
        actualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = null;


                //intent = new Intent(InsertarContacto.this, MainActivity.class);
                // startActivity(intent);
                //Decimos si el nombre y el teléfono están rellenos, si se pueda crear el contacto
                if(!nombre.getText().toString().isEmpty() && !telefono.getText().toString().isEmpty()){
                    //Decimos que el teléfono debe ocupar 9 dígitos
                    if(telefono.length() == 9) {


                        if(e_mail.getText().toString().indexOf("@") != -1){

                            insertar();
                            Snackbar mensaje = Snackbar.make(view, "Se ha añadido correctamente", 2000);
                            mensaje.show();
                            Intent intent1 = new Intent(InsertarContactoOculto.this, MainActivity.class);
                            startActivity(intent1);

                        }else{
                            Snackbar mensaje = Snackbar.make(view, "No se ha podido añadir el contacto, comprueba que el \n" +
                                    "campo correo tenga el carácter @", 2000);
                            mensaje.show();
                        }
                    }else{
                        Snackbar mensaje = Snackbar.make(view, "No se ha podido añadir el contacto,\nRecuerda que" +
                                " el teléfono debe ocupar 9 números", 4000);
                        mensaje.show();

                    }

                }else {
                    Snackbar mensaje = Snackbar.make(view, "No se ha podido añadir el contacto,\n el nombre" +
                            "o el teléfono no están rellenos", 4000);
                    mensaje.show();
                }


                Result res;
            }
        });


        }




    public void insertar(){
        ConexionSQLiteBaseDatos conn = new ConexionSQLiteBaseDatos(this, BaseDatos.BASE_DATOS_CONTACTOS, null, 1);



        SQLiteDatabase db= conn.getWritableDatabase();
        String insert = "INSERT INTO " + BaseDatos.TABLA_CONTACTOS_OCULTOS+ " ( "
                + BaseDatos.CAMPO_NOMBRE +" , "
                + BaseDatos.CAMPO_TELÉFONO + " , "
                + BaseDatos.CAMPO_E_MAIL + " , "
                +BaseDatos.CAMPO_DIRECCION + " ) "
                + " VALUES('"
                + nombre.getText().toString() + "' , '"
                + telefono.getText().toString() + "', '"
                + e_mail.getText().toString() +"', '"
                + direccion.getText().toString() + "');";

        db.execSQL(insert);
        db.close();
    }
}