package com.example.fragmentoloko.Entidades;

public class Contacto {

    private Integer id;
    private String nombre;
    private Integer telefono;
    private String e_mail;
    private String direccion;

    public Contacto(){

    }

    public Contacto(String nombre, int telefono){

        this.nombre = nombre;
    }

    public Integer getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public Integer getTelefono() {
        return telefono;
    }

    public String getE_mail() {
        return e_mail;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setTelefono(Integer telefono) {
        this.telefono = telefono;
    }

    public void setE_mail(String e_mail) {
        this.e_mail = e_mail;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Contacto(Integer id, String nombre, Integer telefono, String e_mail, String direccion) {
        this.id = id;
        this.nombre = nombre;
        this.telefono = telefono;
        this.e_mail = e_mail;
        this.direccion = direccion;
    }
}



