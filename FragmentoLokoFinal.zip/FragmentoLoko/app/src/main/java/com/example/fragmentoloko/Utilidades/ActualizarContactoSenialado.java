package com.example.fragmentoloko.Utilidades;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.fragmentoloko.Entidades.Contacto;
import com.example.fragmentoloko.MainActivity;
import com.example.fragmentoloko.R;

import java.util.ArrayList;

public class ActualizarContactoSenialado extends AppCompatActivity {
    EditText campoNombre, campoTelefono, campoE_mail,campoDireccion, campoEscogido;
    Button btnActualizar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actualizar_contacto_senialado);
        campoNombre = (EditText) findViewById(R.id.textViewNombreContactoActualizar);
        campoTelefono = (EditText)  findViewById(R.id.textView2TelefonoContactoActualizar);
        campoE_mail = (EditText) findViewById(R.id.textView3ContactosEMailActualizar);
        campoDireccion = (EditText)  findViewById(R.id.textView4DireccionContactosActualizar);


        nuevaClase();



        btnActualizar = (Button) findViewById(R.id.btnActualizarContacto);

        btnActualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                actualizarContacto();

                Intent intent = new Intent(ActualizarContactoSenialado.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private void nuevaClase(){

        ConexionSQLiteBaseDatos conn = new ConexionSQLiteBaseDatos(this, BaseDatos.BASE_DATOS_CONTACTOS, null, 1);



        ListView nuevaLista = (ListView) this.findViewById(R.id.nuevaLista);


        ArrayList<String> listaInformacion = new ArrayList<String>();
        ArrayList<Contacto> arrayListContactos = new ArrayList<Contacto>();

        SQLiteDatabase db = conn.getReadableDatabase(); //Que sea legible, ya que quiero hacer una consulta de lectura
        String selectAll = "SELECT * FROM " + BaseDatos.TABLA_CONTACTOS;

        //Cositas para la conexion
        Contacto contac = null;


        Cursor cursor = db.rawQuery(selectAll, null);

        while(cursor.moveToNext()){
            contac = new Contacto();

            contac.setId(cursor.getInt(0));
            contac.setNombre(cursor.getString(1));
            contac.setTelefono(cursor.getInt(2));
            contac.setE_mail(cursor.getString(3));
            contac.setDireccion(cursor.getString(4));

            arrayListContactos.add(contac);
        }

        for(int i = 0; i < arrayListContactos.size(); i++){
            listaInformacion.add("* Nombre: " +
                    arrayListContactos.get(i).getNombre() + "\n* Telefono " +
                    arrayListContactos.get(i).getTelefono()
            );


        }

        Bundle ssaquito = getIntent().getExtras();
        int codigo = ssaquito.getInt("key");


        campoNombre.setText(arrayListContactos.get(codigo).getNombre());
        campoTelefono.setText(arrayListContactos.get(codigo).getTelefono().toString());
        campoE_mail.setText(arrayListContactos.get(codigo).getE_mail().toString());
        campoDireccion.setText(arrayListContactos.get(codigo).getDireccion().toString());



    }



    private void actualizarContacto() {

        ConexionSQLiteBaseDatos conn = new ConexionSQLiteBaseDatos(this, BaseDatos.BASE_DATOS_CONTACTOS, null, 1);
        SQLiteDatabase db = conn.getReadableDatabase(); //Que sea legible, ya que quiero hacer una consulta de lectura
        String selectAll = "SELECT * FROM " + BaseDatos.TABLA_CONTACTOS;
        Contacto contac = null;
        Cursor cursor = db.rawQuery(selectAll, null);
        ArrayList<Contacto> arrayListContactos = new ArrayList<Contacto>();

        while(cursor.moveToNext()){
            contac = new Contacto();

            contac.setId(cursor.getInt(0));
            contac.setNombre(cursor.getString(1));
            contac.setTelefono(cursor.getInt(2));
            contac.setE_mail(cursor.getString(3));
            contac.setDireccion(cursor.getString(4));

            arrayListContactos.add(contac);
        }
        Bundle ssaquito = getIntent().getExtras();
        int codigo = ssaquito.getInt("key");

        String update = "UPDATE " +BaseDatos.TABLA_CONTACTOS + " SET "
                + BaseDatos.CAMPO_NOMBRE + " = '"
                + campoNombre.getText().toString() + "', "
                + BaseDatos.CAMPO_TELÉFONO + " = '"
                + campoTelefono.getText().toString() + "' , "
                + BaseDatos.CAMPO_E_MAIL + " = '"
                + campoE_mail.getText().toString() + "' ,"
                +BaseDatos.CAMPO_DIRECCION + "= '"
                + campoDireccion.getText().toString() + "' WHERE "
                + BaseDatos.CAMPO_NOMBRE + "= '"
                + arrayListContactos.get(codigo).getNombre() + "';";

        db.execSQL(update);
        db.close();
    }



}