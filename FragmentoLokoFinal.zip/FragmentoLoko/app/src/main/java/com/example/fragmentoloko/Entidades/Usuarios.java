package com.example.fragmentoloko.Entidades;

public class Usuarios {


    private String nombreUsu;
    private String contrasenia;
    private Integer id;


    public Usuarios(){

    }

    Usuarios(String nombreUsu, String contasenia, Integer id){
        this.nombreUsu=nombreUsu;
        this.contrasenia=contasenia;
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombreUsu() {
        return nombreUsu;
    }

    public void setNombreUsu(String nombreUsu) {
        this.nombreUsu = nombreUsu;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }
}
